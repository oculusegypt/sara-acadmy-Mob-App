import WebSocket from 'ws';
const B = 'https://americans-ear-stats-exports.trycloudflare.com';
const W = 'wss://americans-ear-stats-exports.trycloudflare.com';

const sch = await (await fetch(B + '/api/schedule')).json();
const list = Array.isArray(sch) ? sch : (sch.sessions || sch.data || []);
console.log('sessions:', JSON.stringify(list.map(s => ({ id: s.id, open: !!s.open_room }))).slice(0, 400));
const room = list.find(s => s.open_room) || list[0];
if (!room) { console.log('NO ROOMS'); process.exit(1); }
console.log('using room:', room.id, 'openRoom=', !!room.open_room);

let ticket = null;
if (room.open_room) {
  const r = await fetch(B + '/api/live/' + room.id + '/guest-ticket', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'A' }) });
  if (r.ok) { const j = await r.json(); ticket = j.ticket || j.token || null; }
  console.log('guest-ticket HTTP:', r.status);
}

function connect(tk, label) {
  return new Promise((resolve) => {
    const ws = new WebSocket(W + '/realtime/' + room.id + '?ticket=' + encodeURIComponent(tk));
    const out = { label, opened: false, ice: null, chatEcho: false, signalFrom: null, lastRoster: null };
    ws.on('message', (d) => {
      let m; try { m = JSON.parse(d.toString()); } catch { return; }
      if (m.type === 'welcome') { out.ice = m.ice; out.welcomed = true; }
      if (m.type === 'roster') out.lastRoster = m.participants;
      if (m.type === 'signal') out.signalFrom = m.from;
      if (m.type === 'chat') out.chatEcho = true;
    });
    ws.on('close', (code) => { out.closeCode = code; resolve(out); });
    ws.on('error', (e) => { out.error = String(e).slice(0, 80); });
    ws.on('open', () => {
      out.opened = true;
      setTimeout(() => { try { ws.send(JSON.stringify({ type: 'chat', text: 'ping-' + label })); } catch {} }, 800);
      setTimeout(() => { try { ws.close(); } catch {} }, 3500);
    });
    setTimeout(() => resolve(out), 12000);
  });
}

if (ticket) {
  // اتصالان متزامنان حقيقيان لنفس الغرفة — اختبار روسترة + بث شات + إشارات
  const [a, b] = await Promise.all([connect(ticket, 'A'), connect(ticket, 'B')]);
  console.log('CONN A:', JSON.stringify(a).slice(0, 700));
  console.log('CONN B:', JSON.stringify(b).slice(0, 700));
} else {
  const bad = await connect('invalid-ticket', 'BAD');
  console.log('CONN BAD-TICKET (expect close 440):', JSON.stringify(bad).slice(0, 300));
}
