import WebSocket from 'ws';
const B = 'https://americans-ear-stats-exports.trycloudflare.com';
const W = 'wss://americans-ear-stats-exports.trycloudflare.com';
const slist = await (await fetch(B + '/api/live-sessions')).json();
const room = (Array.isArray(slist) ? slist : slist.sessions)[0];
async function j(url, body) { const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { status: r.status, json: await r.json().catch(() => null) }; }
const stamp = Date.now();
const uA = await j(B + '/api/auth/register', { name: 'مرسل A', email: `sA_${stamp}@orbit.test`, password: 'Test1234!', role: 'learner' });
const uB = await j(B + '/api/auth/register', { name: 'مستقبِل B', email: `sB_${stamp}@orbit.test`, password: 'Test1234!', role: 'learner' });
await j(B + '/api/enroll', { userId: uA.json.id, courseId: room.courseId || room.course_id, source: 'test' });
await j(B + '/api/enroll', { userId: uB.json.id, courseId: room.courseId || room.course_id, source: 'test' });
const tkA = (await j(B + `/api/live/${room.id}/ticket`, { userId: uA.json.id, name: 'مرسل A', role: 'learner' })).json.token;
const tkB = (await j(B + `/api/live/${room.id}/ticket`, { userId: uB.json.id, name: 'مستقبِل B', role: 'learner' })).json.token;

function open(tk, label) {
  return new Promise((resolve) => {
    const ws = new WebSocket(W + '/realtime/' + room.id + '?token=' + encodeURIComponent(tk));
    const out = { label, selfId: null, peers: [], signals: [], mediaStates: [] };
    ws.on('message', (d) => {
      const m = JSON.parse(d.toString());
      if (m.type === 'welcome') out.selfId = m.self.id;
      if (m.type === 'roster') out.peers = (m.participants || []).map(p => p.id);
      if (m.type === 'signal') out.signals.push({ from: m.from, to: m.to, kind: m.data?.type });
      if (m.type === 'media-state') out.mediaStates.push(m);
    });
    ws.on('open', () => setTimeout(() => resolve(ws), 2500));
  });
}
// نتصل تباعاً حتى يعرف كل منهما roster الآخر ثم نرسل offer من A إلى B
const wsA = await new Promise(res => { const w = new WebSocket(W + '/realtime/' + room.id + '?token=' + encodeURIComponent(tkA)); const a = { signals: [], peers: [], self: null }; w.on('message', d => { const m = JSON.parse(d.toString()); if (m.type==='welcome') a.self=m.self.id; if (m.type==='roster') a.peers=(m.participants||[]).map(p=>p.id); if (m.type==='signal') a.signals.push(m); }); w.on('open', () => setTimeout(()=>res({w,a}), 1500)); });
const wsB = await new Promise(res => { const w = new WebSocket(W + '/realtime/' + room.id + '?token=' + encodeURIComponent(tkB)); const b = { signals: [], peers: [] }; w.on('message', d => { const m = JSON.parse(d.toString()); if (m.type==='roster') b.peers=(m.participants||[]).map(p=>p.id); if (m.type==='signal') b.signals.push(m); }); w.on('open', () => setTimeout(()=>res({w,b}), 1500)); });
console.log('A sees peers:', wsA.a.peers, '| B sees peers:', wsB.b.peers);
// A يرسل signal offer إلى B (كما يفعل العميل الحقيقي)
wsA.w.send(JSON.stringify({ type: 'signal', to: wsB.b_last || (wsA.a.peers.find(p => p !== wsA.a.self)), data: { type: 'offer', sdp: 'v=0 FAKE-OFFER-TEST' } }));
// A يعلن حالة وسائط (شاشة مفتوحة) كما يفعل عند بدء المشاركة
wsA.w.send(JSON.stringify({ type: 'media-state', mic: true, cam: false, screen: true }));
await new Promise(r => setTimeout(r, 1500));
console.log('B received signals:', JSON.stringify(wsB.b.signals));
wsB.w.close(); wsA.w.close();
