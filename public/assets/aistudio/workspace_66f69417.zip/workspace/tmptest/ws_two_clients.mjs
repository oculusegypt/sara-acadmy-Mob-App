import WebSocket from 'ws';
const B = 'https://americans-ear-stats-exports.trycloudflare.com';
const W = 'wss://americans-ear-stats-exports.trycloudflare.com';
const sess = await (await fetch(B + '/api/live-sessions')).json();
const slist = Array.isArray(sess) ? sess : (sess.sessions || []);
const room = slist[0]; const roomId = room.id; const courseId = room.courseId || room.course_id;
async function j(url, body) { const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { status: r.status, json: await r.json().catch(() => null) }; }
const stamp = Date.now();
const uA = await j(B + '/api/auth/register', { name: 'مشارك A', email: `mA_${stamp}@orbit.test`, password: 'Test1234!', role: 'learner' });
const uB = await j(B + '/api/auth/register', { name: 'مشارك B', email: `mB_${stamp}@orbit.test`, password: 'Test1234!', role: 'learner' });
await j(B + '/api/enroll', { userId: uA.json.id, courseId, source: 'test' });
await j(B + '/api/enroll', { userId: uB.json.id, courseId, source: 'test' });
const tkA = await j(B + `/api/live/${roomId}/ticket`, { userId: uA.json.id, name: 'مشارك A', role: 'learner' });
const tkB = await j(B + `/api/live/${roomId}/ticket`, { userId: uB.json.id, name: 'مشارك B', role: 'learner' });
console.log('tickets:', tkA.status, tkB.status);

function connect(tk, label, otherHint) {
  return new Promise((resolve) => {
    const ws = new WebSocket(W + '/realtime/' + roomId + '?token=' + encodeURIComponent(tk));
    const out = { label, welcomed: false, rosterSeen: null, chatSeen: [], signalFrom: null };
    ws.on('message', (d) => {
      let m; try { m = JSON.parse(d.toString()); } catch { return; }
      if (m.type === 'welcome') { out.welcomed = true; out.selfId = m.self?.id; }
      if (m.type === 'roster') out.rosterSeen = (m.participants || []).map(p => p.name);
      if (m.type === 'chat') out.chatSeen.push((m.fromName || m.from || '?') + ': ' + m.text);
      if (m.type === 'signal') out.signalSeen = m.data?.type;
    });
    ws.on('open', () => {
      setTimeout(() => { try { ws.send(JSON.stringify({ type: 'chat', text: 'ping-' + label })); } catch {} }, 900);
      setTimeout(() => { try { ws.send(JSON.stringify({ type: 'hand', kind: 'raise' })); } catch {} }, 1200);
      setTimeout(() => { try { ws.close(); } catch {} }, 4000);
    });
    ws.on('close', () => resolve(out));
    setTimeout(() => resolve(out), 8000);
  });
}
// اتصالان متزامنان حقيقيان في نفس الغرفة عبر الإنتاج
const [a, b] = await Promise.all([connect(tkA.json.token, 'A'), connect(tkB.json.token, 'B')]);
console.log('A:', JSON.stringify(a));
console.log('B:', JSON.stringify(b));
