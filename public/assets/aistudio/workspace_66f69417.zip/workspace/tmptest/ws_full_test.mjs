import WebSocket from 'ws';
const B = 'https://americans-ear-stats-exports.trycloudflare.com';
const W = 'wss://americans-ear-stats-exports.trycloudflare.com';

// 1) اعرف الغرفة ودورتها
const sess = await (await fetch(B + '/api/live-sessions')).json();
const slist = Array.isArray(sess) ? sess : (sess.sessions || []);
console.log('live sessions:', JSON.stringify(slist.map(s => ({ id: s.id, course: s.courseId || s.course_id, open: !!(s.openRoom ?? s.open_room) }))).slice(0, 400));
const room = slist[0];
if (!room) { console.log('NO SESSIONS'); process.exit(1); }
const roomId = room.id;
const courseId = room.courseId || room.course_id;

async function j(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: r.status, json: await r.json().catch(() => null) };
}

// 2) سجّل طالبين حقيقيين جديدين
const stamp = Date.now();
const uA = await j(B + '/api/auth/register', { name: 'طالب اختبار A', email: `testA_${stamp}@orbit.test`, password: 'Test1234!', role: 'learner' });
const uB = await j(B + '/api/auth/register', { name: 'طالب اختبار B', email: `testB_${stamp}@orbit.test`, password: 'Test1234!', role: 'learner' });
console.log('register A:', uA.status, JSON.stringify(uA.json).slice(0, 120));
console.log('register B:', uB.status, JSON.stringify(uB.json).slice(0, 120));
const idA = uA.json?.id, idB = uB.json?.id;
if (!idA || !idB) process.exit(1);

// 3) اشترك A في دورة الغرفة (مسار الاشتراك الحقيقي المطابق لواجهة المتجر)
const enr = await j(B + '/api/enroll', { userId: idA, courseId, source: 'test' });
console.log('enroll A:', enr.status, JSON.stringify(enr.json).slice(0, 150));

// 4) اطلب بطاقة دخول A — يجب 200 الآن، وبطاقة B — يجب 403 (غير مشترك)
const tkA = await j(B + `/api/live/${roomId}/ticket`, { userId: idA, name: 'طالب اختبار A', role: 'learner' });
const tkB = await j(B + `/api/live/${roomId}/ticket`, { userId: idB, name: 'طالب اختبار B', role: 'learner' });
console.log('ticket A:', tkA.status, tkA.json?.token ? 'TOKEN ISSUED ttl=' + tkA.json.expiresInMinutes + 'm' : JSON.stringify(tkA.json).slice(0, 160));
console.log('ticket B (expect 403):', tkB.status);

const tokenA = tkA.json?.token;
if (!tokenA) { console.log('NO TOKEN — aborting WS part'); process.exit(1); }

// 5) اتصالان WS حقيقيان متزامنان: A ببطقة صالحة، B بدون — يفترض رفض B وبقاء A مع roster صحيح
function connect(tk, label) {
  return new Promise((resolve) => {
    const url = W + '/realtime/' + roomId + '?token=' + encodeURIComponent(tk);
    const ws = new WebSocket(url);
    const out = { label, opened: false, welcomed: false, ice: null, hasTurnIce: false, chatSeen: [], rosterSeen: null, closeCode: null };
    ws.on('message', (d) => {
      let m; try { m = JSON.parse(d.toString()); } catch { return; }
      if (m.type === 'welcome') {
        out.welcomed = true;
        out.ice = m.ice ? m.ice.servers.length : 0;
        out.hasTurnIce = !!(m.ice && m.ice.hasTurn);
        out.selfName = m.self?.name;
      }
      if (m.type === 'roster') out.rosterSeen = (m.participants || []).map(p => p.name);
      if (m.type === 'chat') out.chatSeen.push(m.from + ':' + m.text);
    });
    ws.on('close', (code) => { out.closeCode = code; resolve(out); });
    ws.on('error', (e) => { out.error = String(e).slice(0, 60); });
    ws.on('open', () => {
      out.opened = true;
      setTimeout(() => { try { ws.send(JSON.stringify({ type: 'chat', text: 'ping-' + label })); } catch {} }, 700);
      setTimeout(() => { try { ws.close(); } catch {} }, 3000);
    });
    setTimeout(() => resolve(out), 9000);
  });
}

const [a, b] = await Promise.all([connect(tokenA, 'A'), connect('fake-ticket-B', 'B')]);
console.log('WS A:', JSON.stringify(a).slice(0, 500));
console.log('WS B (expect reject 440):', JSON.stringify(b).slice(0, 200));

// 6) تحقق من سجل التدقيق الحي للعمليات السابقة
const audit = await (await fetch(B + '/api/audit?limit=8')).json();
const rows = Array.isArray(audit) ? audit : (audit.rows || audit.data || []);
console.log('AUDIT latest:', JSON.stringify(rows.slice(0, 5).map(r => r.action || r.action_type)).slice(0, 300));
