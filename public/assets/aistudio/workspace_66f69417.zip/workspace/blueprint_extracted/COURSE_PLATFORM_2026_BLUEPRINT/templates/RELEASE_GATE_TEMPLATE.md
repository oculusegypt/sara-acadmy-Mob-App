# Release Gate
- Release/commit:
- Environment:
- Gate owner:
- Date:

## Required evidence
- [ ] CI passed on exact commit
- [ ] P0 acceptance criteria traced to tests/evidence
- [ ] No open Critical/High security findings
- [ ] Payment/webhook idempotency tests passed (if applicable)
- [ ] Access-control negative tests passed
- [ ] Accessibility/RTL checks passed for critical journeys
- [ ] Performance report includes environment and percentiles
- [ ] Backup restore test within approved RPO/RTO
- [ ] Dependency/SBOM/license checks reviewed
- [ ] Observability and alerts verified
- [ ] Rollback/forward-fix plan tested or rehearsed
- [ ] Privacy/data retention and vendor settings reviewed
- [ ] Human go/no-go recorded

## Known limitations and accepted risks
## Decision: GO / NO-GO
## Approver and timestamp
