# ADR-NNN: <title>
- Status: proposed / accepted / superseded
- Owner:
- Date:
- Related requirements:
- Reviewers:

## Context and problem
## Constraints and threat considerations
## Options considered
| Option | Benefits | Costs | Risks | Reversibility |
|---|---|---|---|---|
## Decision
## Evidence / PoC
- Environment and versions:
- Commands / method:
- Results:
- Limitations:
## Security / privacy / accessibility impact
## Operations and cost impact
## Rollout and rollback
## Revisit when
