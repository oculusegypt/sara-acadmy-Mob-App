# Incident Runbook
- Incident ID / severity:
- Incident commander:
- Start time / detection source:
- Customer impact:
- Suspected systems/data:

## First 15 minutes
1. Confirm incident and assign commander.
2. Preserve logs and evidence; avoid destructive cleanup.
3. Contain safely (revoke token, disable feature flag, isolate worker) with approval level appropriate to severity.
4. Establish internal communication channel and status cadence.
5. Determine whether personal/financial data or legal reporting duties may be involved.

## Investigation
- Timeline:
- Indicators / queries:
- Scope and affected users:
- Root cause hypotheses and evidence:

## Recovery
- Containment completed:
- Recovery validation:
- Customer communication:
- Monitoring window:

## Post-incident
- Root cause and contributing factors:
- Action items with owner/date:
- Tests/alerts added:
- Lessons learned; no-blame review:
