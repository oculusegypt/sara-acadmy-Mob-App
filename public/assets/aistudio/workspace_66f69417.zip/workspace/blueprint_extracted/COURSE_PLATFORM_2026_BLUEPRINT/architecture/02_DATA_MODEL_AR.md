# نموذج البيانات المنطقي

## الكيانات الأساسية

- `users`: الهوية والحالة وبيانات الملف الشخصي الدنيا.
- `roles`, `user_roles`: صلاحيات عامة، مع authorization على مستوى المورد.
- `instructors`: بيانات المدرس وحالة التحقق.
- `courses`: slug، عنوان، وصف، لغة، مستوى، سعر، عملة، حالة، owner، version.
- `course_sections`: وحدات مرتبة داخل الدورة.
- `lessons`: محتوى/نوع/مدة/ترتيب/حالة.
- `media_assets`: مزود، معرف أصل خارجي، حالة المعالجة، metadata آمنة.
- `enrollments`: user/course/status/source/enrolled_at; unique(user_id, course_id) حسب نموذج الشراء.
- `lesson_progress`: user/lesson/progress/status/last_position/updated_at; upsert idempotent.
- `quizzes`, `quiz_questions`, `quiz_options`, `quiz_attempts`, `quiz_answers`: لا ترسل correct flag للعميل قبل الموعد المسموح.
- `payments`, `payment_events`, `refunds`: حالات ومرجع المزود وidempotency؛ لا بيانات بطاقة خام.
- `certificates`: public verification id عشوائي، قواعد إصدار، issued/revoked timestamps.
- `ai_conversations` (اختياري): أقل قدر من البيانات؛ سياسة retention واضحة.
- `audit_events`: actor/action/resource/reason/metadata sanitized/timestamp.
- `outbox_events`: events جاهزة للنشر مع attempts وpublished_at.

## قيود يجب فرضها

- unique idempotency key ضمن scope مناسب.
- unique provider event ID.
- check amount >= 0، عملة من قائمة معتمدة، وحالات transition مسموحة.
- foreign keys وsoft-delete/archive حيث يلزم تاريخ التعلم/المال.
- فهارس على course slug/status، enrollment user/course، progress user/lesson، payment provider reference، audit timestamp.
- لا تحفظ أسرار أو access tokens في metadata JSON.
- لا تسمح بربط شهادة بدورة غير مكتملة دون قاعدة معلنة ومسجلة.

## multi-tenancy

إن استُهدف B2B، أضف `organization_id` مع سياسات عزل واختبارات cross-tenant لكل query/endpoint. لا تعتبر وجود organization_id في الجدول وحده عزلًا كافيًا. يمكن استخدام PostgreSQL RLS كطبقة دفاع إضافية بعد مراجعة connection/session context.
