# المعمارية المرجعية

## قرار معماري

**ابدأ بـ modular monolith** مقسم إلى modules ذات حدود واضحة، مع workers للمهام الطويلة. الفصل إلى خدمات مستقلة لاحقًا قرار مبني على الحمل وحدود الفريق، لا على الموضة.

## الطبقات

1. **Experience:** Next.js web app، صفحات عامة قابلة للفهرسة، مساحة تعلم محمية، لوحة مدرس، لوحة مشرف.
2. **Application/API:** use cases وvalidation وauthorization وrate limits؛ لا قواعد مالية في العميل.
3. **Domain modules:** Identity, Catalog, Course Authoring, Enrollment, Billing, Learning Progress, Assessment, Certificates, Media, AI Tutor, Notifications, Support, Analytics, Audit.
4. **Persistence:** PostgreSQL، object storage، cache اختياري، search index عند الحاجة.
5. **Async:** queue + workers لرسائل البريد ومعالجة media/webhooks/reports.
6. **External adapters:** Payment provider، Video provider، Email/SMS، AI model provider، analytics sink.
7. **Operations:** secrets manager، CI/CD، monitoring، backup/restore، feature flags.

## حدود الثقة

- المتصفح غير موثوق؛ السعر وحق الالتحاق والدرجة وحالة الدفع لا تأتي من قيم العميل وحدها.
- مزود الدفع لا يثبت الحدث إلا بعد التحقق من webhook أو تحقق server-to-server.
- مزود الفيديو يسلّم الوسائط؛ منصة التعلم تظل مسؤولة عن قرار من يحق له المشاهدة.
- ملفات الدورات والنصوص المسترجعة من AI بيانات غير موثوقة.
- لوحة الإدارة منطقة عالية الحساسية: MFA، least privilege، audit.

## تدفق الشراء

Client → Create checkout (server validates course price) → Provider hosted checkout → Signed webhook → Verify signature + dedupe event → Payment state transition + enrollment in DB transaction/outbox → Notify user → Reconciliation.

## تدفق الفيديو

Client asks playback → server verifies identity + active enrollment + course/lesson availability → short-lived provider token → player fetches manifest/segments → telemetry without token leakage. Re-check entitlement when issuing token; token lifetime is a risk control, not a substitute for revocation strategy.

## تدفق AI Tutor

User query → authorization → retrieval filtered by course enrollment → prompt assembly with untrusted-content boundary → model adapter → output/source validation → answer + citations → privacy-filtered telemetry.

## قواعد الاتساق

- معاملات DB للعمليات المحلية ذات الاتساق المطلوب.
- Outbox pattern عند الحاجة لنشر event بعد commit دون فقده.
- webhook handlers idempotent مع unique event ID.
- لا تعتمد على exactly-once delivery؛ صمم at-least-once مع idempotent consumers.
- لا تستخدم cache كمصدر حقيقة للمال أو الصلاحيات.
