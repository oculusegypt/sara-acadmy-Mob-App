# كتالوج الأحداث الداخلي

الأحداث داخلية وليست بالضرورة API عامة. استخدم `event_id`, `occurred_at`, `schema_version`, `correlation_id`, `actor_type`, و`tenant_id` عند انطباقه. لا تضع email أو نص محادثة أو token في metadata افتراضيًا.

| الحدث | مصدره | مستهلك محتمل | ضمانات |
|---|---|---|---|
| user.registered | Identity | email worker, analytics | idempotent notification |
| course.published | Catalog | search index, cache invalidation | versioned course |
| media.processing.completed | media webhook | media module | verify signature + dedupe |
| checkout.created | Billing | analytics | لا يعني أن الدفع تم |
| payment.succeeded | verified provider webhook | enrollment, receipt | transaction/outbox + idempotency |
| payment.refunded | verified refund/webhook | enrollment policy, notification | refund record + ledger |
| learner.enrolled | Enrollment | course access, analytics | unique enrollment constraint |
| lesson.progress.updated | Learning | analytics, resume state | upsert/idempotent |
| quiz.attempt.submitted | Assessment | scoring, progress | server-side scoring |
| certificate.issued | Certificates | notification, verification | rule evaluation + audit |
| ai.answer.reported | AI Tutor | moderation/quality review | privacy-minimized payload |

## سياسة التوصيل

افترض أن الرسائل قد تتكرر أو تتأخر أو تصل خارج الترتيب. المستهلك يزيل التكرار ويقبل إعادة المحاولة. استخدم outbox عندما يجب أن يتبع الحدث transaction ناجحة. لا تضع منطق مالي حاسم داخل مستهلك analytics.
