# دليل النشر والتشغيل

## قبل أول نشر

- حسم provider accounts ومناطق البيانات والاتفاقيات.
- مراجعة ADRs والمخطط الأمني وبيانات الاتصال.
- إعداد secrets في secret manager، لا في `.env` الملتزم بالمستودع.
- إنشاء staging مع بيانات اصطناعية.
- إعداد CI: format/lint/typecheck/unit/contract/integration/security/dependency/license/SBOM.
- إعداد migration dry run وbackup قبل أي migration حساسة.

## خطوات الإصدار

1. تجميد release candidate وتحديد commit hash.
2. تشغيل CI على نفس commit.
3. مراجعة release gate والتغييرات في DB/API.
4. نشر إلى staging واختبار smoke + E2E + webhooks sandbox.
5. اعتماد بشري من مالك الإصدار والأمن عند التغييرات الحساسة.
6. نشر تدريجي/feature flag إن أمكن.
7. تحقق بعد النشر: errors, latency, webhook lag, playback errors, payment reconciliation.
8. تفعيل rollback/forward fix إذا تجاوزت مؤشرات التوقف.

## معايير التراجع

- وصول غير مصرح به مؤكد إلى محتوى/بيانات.
- خلل مالي قد يكرر الرسوم أو الالتحاق.
- ارتفاع أخطاء الرحلة الحرجة فوق الحد المتفق عليه.
- فقد بيانات أو فشل migration دون مسار آمن.
- استهلاك غير طبيعي لمزود AI أو الفيديو.

## متغيرات البيئة

استخدم `operations/ENVIRONMENT_VARIABLES.example` كقائمة أسماء فقط. لا تضع قيمًا حقيقية في الحزمة أو السجلات. قيم placeholder ليست أسرارًا صالحة.
