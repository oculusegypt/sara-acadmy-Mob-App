# خارطة الطريق المرحلية

المدد تقديرية فقط وتُراجع بعد معرفة حجم الفريق والخبرة والميزانية ومزودي الخدمة. لا توجد وعود بإطلاق خلال مدة ثابتة قبل PoC.

## G0 — اكتشاف وتثبيت النطاق (1–2 أسبوع تقديري)
- مقابلات متعلمين ومدرسين؛ نموذج إيراد وسوق إطلاق.
- تعريف السياسات: حقوق المحتوى، الخصوصية، الاسترداد، الإتاحة، الاحتفاظ.
- تحديد متطلبات P0 ومعايير القبول ومالك كل مجال.
- مخرجات: PRD، data map، risk register، success metrics baseline plan.

## G1 — قرارات معمارية وتجارب جدوى (2–3 أسابيع تقديري)
- PoC تسجيل/صلاحيات، فيديو signed playback، hosted checkout + webhook، RTL/accessibility.
- قياس تكلفة المزود وجودة الفيديو والتوافق الجغرافي.
- ADRs مع بدائل ونتائج قابلة لإعادة الإنتاج.

## G2 — الأساس والكتالوج (2–4 أسابيع تقديري)
- مستودع، CI، design tokens، identity، catalog، course authoring draft/review/publish.
- migrations، logs/metrics، backup setup.

## G3 — رحلة التعلم (3–5 أسابيع تقديري)
- enrollment، lesson player، progress، quizzes، certificates، notifications.
- E2E من التسجيل حتى شهادة اختبارية.

## G4 — المدفوعات والإدارة (2–4 أسابيع تقديري)
- payment state machine، idempotency، refunds، reconciliation، audit trail.
- negative authorization tests وفحص webhook replay.

## G5 — AI Tutor محدود (اختياري، 2–4 أسابيع تقديري)
- مصادر معتمدة فقط، retrieval filtering، تقييم groundedness، prompt injection suite، budgets.
- لا يوقف إطلاق MVP إذا لم يكن ضمن هدف المنتج الأولي.

## G6 — hardening وBeta (2–4 أسابيع تقديري)
- اختبارات أمن/إتاحة/حمل/تعافي، اختبار استعادة backup، تجربة مستخدم، مراقبة وتنبيهات.
- إطلاق محدود ومراقبة الأخطاء والتكلفة.

## G7 — قرار الإطلاق والتوسع
- go/no-go بشري موثق، rollback جاهز، دعم عملاء، incident on-call.
- بعد استقرار المقاييس: تقييم live classes، B2B tenancy، PWA، توصيات أوسع.

## اعتماديات حرجة

- لا checkout قبل تحديد السوق/العملة/الضرائب/سياسة refund ومزود الدفع.
- لا AI Tutor قبل اعتماد سياسة البيانات ومصادر المحتوى وevaluation set.
- لا B2B قبل نموذج tenant isolation واختبارات cross-tenant.
- لا شهادات قابلة للتحقق قبل سياسة إصدار وإبطال وخصوصية صفحة التحقق.
