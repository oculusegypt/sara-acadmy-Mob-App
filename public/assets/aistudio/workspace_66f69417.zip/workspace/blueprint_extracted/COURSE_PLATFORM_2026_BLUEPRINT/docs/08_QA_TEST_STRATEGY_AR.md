# 08 — استراتيجية الجودة والاختبار

## طبقات الاختبار

1. **Unit:** قواعد التقدم، الأسعار، الضرائب، صلاحيات الحالة، تحويل العملة، إصدار الشهادة.
2. **Contract:** OpenAPI، webhooks، adapter الفيديو والدفع، ومخططات الأحداث.
3. **Integration:** PostgreSQL، queue/worker، object storage، مزودات sandbox.
4. **E2E:** تسجيل → اكتشاف دورة → شراء sandbox → webhook → التحاق → مشاهدة درس → اختبار → شهادة.
5. **Security:** authorization negative tests، IDOR، injection، CSRF، XSS، SSRF في استيراد الروابط إن وجد، رفع ملفات، replay.
6. **Accessibility:** axe أو ما يعادله + مراجعة لوحة مفاتيح وقارئ شاشة وتباين/تكبير.
7. **Performance:** اختبار حمل منفصل للكتالوج، تسجيل الدخول، حفظ التقدم، وإصدار playback token؛ لا تخلط تحميل الفيديو CDN مع زمن API.
8. **Resilience:** فشل مزود الدفع، تأخر/تكرار webhook، queue backlog، انقطاع DB، استعادة backup.
9. **Content quality:** مراجعة حقوق وإتاحة ودقة ومخرجات التعلم.
10. **AI evaluation:** groundedness، leakage، prompt injection، bias، refusal، latency، cost.

## سياسة الاختبار

- كل bug يعاد إنتاجه قبل إصلاحه ويضاف regression test.
- الاختبار المتقلب لا يحذف لإخضرار CI؛ يوسم ويعالج مع مالك وموعد.
- لا تستخدم بيانات حقيقية أو أسرارًا في snapshots/logs.
- كل معيار قبول P0 مرتبط باختبار أو دليل يدوي موقع.
- Coverage رقم مساعد وليس دليل صحة؛ لا تُفرض نسبة 100% على كل الملفات كبديل عن تصميم الاختبارات.

## بوابة الجودة

- CI أخضر على commit المرشح.
- لا ثغرات Critical/High مفتوحة.
- لا أخطاء دفع أو وصول لمحتوى مدفوع في الاختبارات.
- أداء ضمن أهداف baseline المتفق عليها مع تقرير قابل لإعادة الإنتاج.
- اختبارات الإتاحة واللغة وRTL اجتازت قائمة القبول.
- استعادة backup نجحت ضمن RTO/RPO المعتمدين.
- Release notes، migration plan، rollback plan، وموافقة مالك الإصدار.
