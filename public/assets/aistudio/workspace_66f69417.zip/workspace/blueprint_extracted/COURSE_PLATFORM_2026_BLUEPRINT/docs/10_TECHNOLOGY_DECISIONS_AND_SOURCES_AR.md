# 10 — قرارات تقنية ومصادر مرجعية

## التوصية التقنية المبدئية

| المجال | الاختيار المبدئي | لماذا | شرط إعادة التقييم |
|---|---|---|---|
| واجهة الويب | Next.js App Router + TypeScript | SSR/metadata للكتالوج وتجربة تفاعلية؛ يدعم فصل Server/Client Components | تحقق من الإصدار المستقر والتوافق قبل التثبيت |
| UI | Design tokens + مكتبة مكونات قابلة للإتاحة | اتساق وRTL واختبارات | لا تعتمد مكتبة دون اختبار keyboard/RTL |
| قاعدة البيانات | PostgreSQL | معاملات وعلاقات وقيود وفهرسة قوية | benchmark على بيانات واقعية |
| ملفات عامة/خاصة | Object storage + CDN | تخزين قابل للتوسع | تقييم مناطق البيانات والتشفير والتكلفة |
| فيديو | مزود managed video عبر adapter | تفادي بناء transcoding/CDN من الصفر | PoC للتكلفة والجودة والإقليم وsigned playback |
| الدفع | Hosted checkout لمزود مناسب للسوق | تقليل نطاق بيانات البطاقة | مراجعة الدعم المحلي والاسترداد والضرائب |
| البحث | PostgreSQL full-text كبداية، ثم محرك متخصص عند الحاجة | أقل تعقيدًا أوليًا | جودة استعلامات عربية/حجم الكتالوج |
| المهام | Queue/worker managed أو موثوق | فيديو، بريد، تقارير، webhook retries | لا تبنِ queue مخصصة دون حاجة |
| الرصد | OpenTelemetry + backend مناسب | vendor-neutral telemetry | راقب كلفة cardinality والاحتفاظ |
| الأمن | OWASP ASVS 5.0.0 + threat model | متطلبات تحقق منظمة | تحديد مستوى التحقق وفق المخاطر |
| الإتاحة | WCAG 2.2 AA هدف | معيار قابل للاختبار | مراجعة يدوية وتقنية لكل رحلة حرجة |

## مصادر رسمية تمت مراجعتها في 1 نوفمبر 2026

- Next.js App Router: https://nextjs.org/docs/app — توثيق رسمي؛ تحقق من أحدث إصدار مستقر قبل التثبيت.
- Next.js Guides: https://nextjs.org/docs/app/guides — يتضمن إرشادات الأمن والاختبار وOpenTelemetry وPWA وغيرها.
- OWASP ASVS: https://asvs.owasp.org/ — يذكر الإصدار المستقر 5.0.0 المنشور في 30 مايو 2025.
- WCAG 2.2: https://www.w3.org/TR/wcag/ — توصية W3C ومستوى AA هدف مناسب للمشروع.
- Cloudflare Stream docs: https://developers.cloudflare.com/stream/ — مثال على مزود managed video؛ الوثائق تشرح signed URLs/webhooks، لكنه مجرد خيار وليس قرارًا نهائيًا.
- Cloudflare Stream securing content: https://developers.cloudflare.com/stream/viewing-videos/securing-your-stream/ — signed URLs وقيود origins؛ لا تلغي الحاجة إلى التحقق من أهلية المستخدم في الخادم.
- Mux docs: https://www.mux.com/docs/core/mux-fundamentals — بديل للمقارنة عند PoC.

## سياسة اعتماد التقنية

لكل اختيار ADR يتضمن: المشكلة، البدائل، تكلفة التشغيل، متطلبات الفريق، مخاطر القفل على المورد، الخصوصية وموقع البيانات، اختبارات PoC، معيار نجاح/فشل، وموعد مراجعة. لا تعتمد عبارة «الأحدث» وحدها سببًا للاختيار.
