-- ORBIT Learn 2026 — initial relational schema sketch
-- Review and test against the selected PostgreSQL version before use.
-- This is a starter schema, not a production-ready migration.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE course_status AS ENUM ('draft','in_review','published','archived');
CREATE TYPE enrollment_status AS ENUM ('active','completed','refunded','revoked');
CREATE TYPE media_status AS ENUM ('uploaded','scanning','processing','ready','failed','archived');
CREATE TYPE payment_status AS ENUM ('created','requires_action','processing','succeeded','failed','refunded','partially_refunded','disputed');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email_normalized TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('pending_verification','active','suspended','deleted')),
  locale TEXT NOT NULL DEFAULT 'ar',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES users(id),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  language_code TEXT NOT NULL DEFAULT 'ar',
  level TEXT NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner','intermediate','advanced','all_levels')),
  status course_status NOT NULL DEFAULT 'draft',
  price_minor BIGINT NOT NULL DEFAULT 0 CHECK (price_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX courses_status_published_idx ON courses(status, published_at DESC);

CREATE TABLE course_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  position INTEGER NOT NULL CHECK (position >= 0),
  UNIQUE(course_id, position)
);

CREATE TABLE media_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL,
  provider_asset_id TEXT,
  status media_status NOT NULL DEFAULT 'uploaded',
  media_kind TEXT NOT NULL CHECK (media_kind IN ('video','audio','document','image','caption')),
  duration_seconds INTEGER CHECK (duration_seconds IS NULL OR duration_seconds >= 0),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider, provider_asset_id)
);

CREATE TABLE lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_id UUID NOT NULL REFERENCES course_sections(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  lesson_kind TEXT NOT NULL CHECK (lesson_kind IN ('video','text','file','quiz','live_placeholder')),
  media_asset_id UUID REFERENCES media_assets(id) ON DELETE RESTRICT,
  body_markdown TEXT,
  position INTEGER NOT NULL CHECK (position >= 0),
  is_preview BOOLEAN NOT NULL DEFAULT FALSE,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(section_id, position)
);

CREATE TABLE enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE RESTRICT,
  status enrollment_status NOT NULL DEFAULT 'active',
  source TEXT NOT NULL CHECK (source IN ('free','purchase','coupon','organization','admin_grant')),
  enrolled_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  UNIQUE(user_id, course_id)
);
CREATE INDEX enrollments_user_status_idx ON enrollments(user_id, status);

CREATE TABLE lesson_progress (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE RESTRICT,
  progress_seconds INTEGER NOT NULL DEFAULT 0 CHECK (progress_seconds >= 0),
  completed_at TIMESTAMPTZ,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  version BIGINT NOT NULL DEFAULT 1,
  PRIMARY KEY(user_id, lesson_id)
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE RESTRICT,
  provider TEXT NOT NULL,
  provider_payment_id TEXT,
  idempotency_key TEXT NOT NULL,
  status payment_status NOT NULL DEFAULT 'created',
  amount_minor BIGINT NOT NULL CHECK (amount_minor >= 0),
  currency CHAR(3) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider, provider_payment_id),
  UNIQUE(provider, idempotency_key)
);

CREATE TABLE payment_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id UUID REFERENCES payments(id) ON DELETE RESTRICT,
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  outcome TEXT NOT NULL DEFAULT 'received',
  safe_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE(provider, provider_event_id)
);

CREATE TABLE refunds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id UUID NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL,
  reason_code TEXT NOT NULL,
  requested_by UUID NOT NULL REFERENCES users(id),
  approved_by UUID REFERENCES users(id),
  provider_refund_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('requested','approved','processing','succeeded','failed','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider_refund_id)
);

CREATE TABLE certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id UUID NOT NULL UNIQUE REFERENCES enrollments(id) ON DELETE RESTRICT,
  verification_code TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(18), 'hex'),
  issued_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ,
  revocation_reason TEXT
);

CREATE TABLE audit_events (
  id BIGSERIAL PRIMARY KEY,
  actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  reason TEXT,
  correlation_id TEXT,
  safe_metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX audit_events_resource_idx ON audit_events(resource_type, resource_id, created_at DESC);

CREATE TABLE outbox_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type TEXT NOT NULL,
  schema_version INTEGER NOT NULL DEFAULT 1,
  aggregate_type TEXT NOT NULL,
  aggregate_id TEXT NOT NULL,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at TIMESTAMPTZ,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0)
);
CREATE INDEX outbox_unpublished_idx ON outbox_events(created_at) WHERE published_at IS NULL;

-- Important implementation notes:
-- 1) Enforce authorization in application/service layer and test every negative case.
-- 2) Do not store card PAN/CVV or provider secrets in any table.
-- 3) Add tenant_id + isolation policies before offering B2B multi-tenancy.
-- 4) Define retention/deletion policy and audit exceptions before production.
-- 5) Production migrations require backup, lock-impact review, rollback/forward-fix plan.
