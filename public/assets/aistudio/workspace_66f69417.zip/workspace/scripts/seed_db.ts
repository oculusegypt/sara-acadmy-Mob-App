import { Client } from 'pg';
import { INITIAL_COURSES } from '../src/components/catalog/data';
import { INITIAL_LIVE_SESSIONS, INITIAL_ASSIGNMENTS } from '../src/services/liveData';

const connectionString = 'postgresql://postgres.iucpnsrfwkfsimktbmgv:zrRHVgoNuC9eulVL@aws-1-eu-central-1.pooler.supabase.com:5432/postgres';

export const INITIAL_LIBRARY_BOOKS = [
  {
    id: 'book-soroban-guide',
    title: 'دليل العباقرة الصغار في الحساب الذهني والسوروبان',
    author: 'أ / سارة العربي',
    category: 'الحساب الذهني وتنمية الذكاء',
    pages_count: 140,
    cover_url: 'https://images.unsplash.com/photo-1596495578065-6e0763fa1178?auto=format&fit=crop&w=600&q=80',
    description: 'المرجع الشامل للأطفال والمدربين لتعلم خوارزميات العداد الصيني، أصدقاء العدد 5 والعدد 10، وتمارين الحساب التخيلي السريع بدون آلة حاسبة.',
    download_url: '#',
    published_year: 2026,
    chapters: [
      { number: 1, title: 'الفصل الأول: مدخل إلى عالم السوروبان وحركة الخرزات', pages: '1-25' },
      { number: 2, title: 'الفصل الثاني: الجمع والطرح المباشر وتدريبات الأصابع', pages: '26-55' },
      { number: 3, title: 'الفصل الثالث: أصدقاء العدد 5 الصغار (Small Friends)', pages: '56-85' },
      { number: 4, title: 'الفصل الرابع: أصدقاء العدد 10 الكبار (Big Friends)', pages: '86-115' },
      { number: 5, title: 'الفصل الخامس: تقنيات الحساب التخيلي (Anzan) وسرعة الاستجابة', pages: '116-140' }
    ]
  },
  {
    id: 'book-nour-al-bayan',
    title: 'سلسلة الفهم مش الحفظ في تأسيس القرائية ونور البيان',
    author: 'أ / سارة العربي',
    category: 'تأسيس اللغة العربية والقرائية',
    pages_count: 160,
    cover_url: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80',
    description: 'منهج تطبيقي لتأسيس الطفل في قراءة الكلمات الثلاثية، التحليل الصوتي للمقاطع، والتمييز بين المدود الطويلة والحركات القصيرة بالفهم والتشويق 💡.',
    download_url: '#',
    published_year: 2026,
    chapters: [
      { number: 1, title: 'الفصل الأول: مخارج الحروف وأصواتها الهجائية بالفتح', pages: '1-35' },
      { number: 2, title: 'الفصل الثاني: دمج الحروف وقراءة الكلمات الثلاثية بالفتح', pages: '36-70' },
      { number: 3, title: 'الفصل الثالث: حركتا الكسر والضم وقراءة الجمل البسيطة', pages: '71-110' },
      { number: 4, title: 'الفصل الرابع: المدود الطويلة (أ، و، ي) والتحليل الصوتي المتقن', pages: '111-160' }
    ]
  },
  {
    id: 'book-smart-math',
    title: 'كتاب الرياضيات الذكية والأنشطة التفاعلية للأطفال',
    author: 'أ / سارة العربي',
    category: 'الرياضيات الذكية والتفكير المنطقي',
    pages_count: 120,
    cover_url: 'https://images.unsplash.com/photo-1518133835878-5a93cc3f89e5?auto=format&fit=crop&w=600&q=80',
    description: 'أنشطة وقصص مصورة لتوضيح القيمة المكانية (بيت الآحاد وقصر العشرات)، استراتيجيات الجمع الذهني ومكونات العدد 10 دون العد على الأصابع.',
    download_url: '#',
    published_year: 2026,
    chapters: [
      { number: 1, title: 'الفصل الأول: قصة بيت الآحاد وقصر العشرات والقيمة المكانية', pages: '1-30' },
      { number: 2, title: 'الفصل الثاني: مكونات العدد 10 واستراتيجيات الجمع الذهني السريع', pages: '31-65' },
      { number: 3, title: 'الفصل الثالث: العد القفزي والأنماط الهندسية للأطفال', pages: '66-95' },
      { number: 4, title: 'الفصل الرابع: حل المسائل الحياتية بالفهم مش الحفظ 💡', pages: '96-120' }
    ]
  },
  {
    id: 'book-tot-guide',
    title: 'دليل المدرب المعتمد في تدريب الحساب الذهني (TOT)',
    author: 'أ / سارة العربي - برنامج العباقرة الصغار',
    category: 'إعداد وتأهيل المدربين - العباقرة الصغار',
    pages_count: 180,
    cover_url: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=600&q=80',
    description: 'الدليل المهني للمعلمات والأمهات لاحتراف تدريس السوروبان للأطفال، إدارة قاعة التدريس التفاعلية، وتصميم المسابقات الحماسية.',
    download_url: '#',
    published_year: 2026,
    chapters: [
      { number: 1, title: 'الفصل الأول: فلسفة برنامج العباقرة الصغار وتدرج المستويات', pages: '1-45' },
      { number: 2, title: 'الفصل الثاني: سيكولوجية الطفل والتغلب على التشتت وصعوبات التعلم', pages: '46-90' },
      { number: 3, title: 'الفصل الثالث: تصميم الأنشطة الحركية والألعاب التعليمية داخل الفصل', pages: '91-135' },
      { number: 4, title: 'الفصل الرابع: أدوات التقييم وسرعة قياس المعالجة الذهنية للأطفال', pages: '136-180' }
    ]
  }
];

async function seed() {
  const client = new Client({
    connectionString,
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();
    console.log('Connected to Supabase PostgreSQL for seeding Miss Sarah Elarby platform...');

    // Clear old sample data to ensure complete freshness
    await client.query('DELETE FROM orbit_courses;');
    await client.query('DELETE FROM orbit_library_books;');
    await client.query('DELETE FROM orbit_live_sessions;');
    await client.query('DELETE FROM orbit_assignments;');

    // Seed Courses
    for (const c of INITIAL_COURSES) {
      await client.query(`
        INSERT INTO orbit_courses (
          id, title, slug, summary, category, level, price_minor, currency,
          duration_hours, rating, reviews_count, thumbnail_url, instructor,
          outcomes, prerequisites, sections, status
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      `, [
        c.id, c.title, c.slug, c.summary, c.category, c.level, c.priceMinor, c.currency,
        c.durationHours, c.rating, c.reviewsCount, c.thumbnailUrl, JSON.stringify(c.instructor),
        JSON.stringify(c.outcomes), JSON.stringify(c.prerequisites), JSON.stringify(c.sections), c.status
      ]);
    }
    console.log(`Courses seeded: ${INITIAL_COURSES.length} courses!`);

    // Seed Books
    for (const b of INITIAL_LIBRARY_BOOKS) {
      await client.query(`
        INSERT INTO orbit_library_books (
          id, title, author, category, pages_count, cover_url, description, download_url, published_year, chapters
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      `, [
        b.id, b.title, b.author, b.category, b.pages_count, b.cover_url, b.description, b.download_url, b.published_year, JSON.stringify(b.chapters)
      ]);
    }
    console.log(`Library books seeded: ${INITIAL_LIBRARY_BOOKS.length} books!`);

    // Seed Live Sessions
    for (const s of INITIAL_LIVE_SESSIONS) {
      await client.query(`
        INSERT INTO orbit_live_sessions (
          id, course_id, course_title, instructor_id, instructor_name, title, description,
          scheduled_at, duration_minutes, status, attendees_count, meeting_code
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      `, [
        s.id, s.courseId, s.courseTitle, s.instructorId, s.instructorName, s.title, s.description,
        s.scheduledAt, s.durationMinutes, s.status, s.attendeesCount, s.meetingCode
      ]);
    }
    console.log(`Live sessions seeded: ${INITIAL_LIVE_SESSIONS.length} sessions!`);

    // Seed Assignments
    for (const a of INITIAL_ASSIGNMENTS) {
      await client.query(`
        INSERT INTO orbit_assignments (
          id, course_id, course_title, title, description, rubric, due_date, max_score
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `, [
        a.id, a.courseId, a.courseTitle, a.title, a.description, JSON.stringify(a.rubric), a.dueDate, a.maxScore
      ]);
    }
    console.log(`Assignments seeded: ${INITIAL_ASSIGNMENTS.length} assignments!`);

    await client.end();
    console.log('Database seeded successfully in Supabase PostgreSQL!');
  } catch (err) {
    console.error('Seeding error:', err);
    process.exit(1);
  }
}

seed();
