#!/usr/bin/env python3
"""
توحيد الاستايل مع الوضع الليلي/النهاري:
يستبدل أصناف Tailwind الداكنة الصلبة بمتغيرات التصميم الدلالية (var(--*))
في الملفات العامة فقط — ويترك وسوم media-dark (مسرح البث) كما هي.
"""
import re, os, sys

DRY = '--apply' not in sys.argv

# خريطة الاستبدال: لون صلب -> متغير دلالي
BG_MAP = {
    'bg-slate-950': 'bg-[var(--bg-inset)]',
    'bg-slate-900': 'bg-[var(--bg-elevated)]',
    'bg-slate-800': 'bg-[var(--bg-subtle)]',
    'bg-slate-700': 'bg-[var(--bg-inset)]',
    'bg-gray-950': 'bg-[var(--bg-inset)]',
    'bg-gray-900': 'bg-[var(--bg-elevated)]',
    'bg-gray-800': 'bg-[var(--bg-subtle)]',
    'bg-zinc-900': 'bg-[var(--bg-elevated)]',
    'bg-neutral-900': 'bg-[var(--bg-elevated)]',
}
BORDER_MAP = {
    'border-slate-700': 'border-[var(--line-strong)]',
    'border-slate-800': 'border-[var(--line)]',
    'border-slate-900': 'border-[var(--line)]',
    'border-gray-700': 'border-[var(--line-strong)]',
    'border-gray-800': 'border-[var(--line)]',
    'border-white/10': 'border-[var(--line)]',
    'border-white/15': 'border-[var(--line)]',
    'border-white/20': 'border-[var(--line-strong)]',
    'divide-slate-800': 'divide-[var(--line)]',
    'divide-gray-800': 'divide-[var(--line)]',
}
TEXT_MAP = {
    'text-white': 'text-[var(--ink)]',
    'text-slate-50': 'text-[var(--ink)]',
    'text-slate-100': 'text-[var(--ink)]',
    'text-slate-200': 'text-[var(--ink)]',
    'text-slate-300': 'text-[var(--ink-soft)]',
    'text-slate-400': 'text-[var(--ink-soft)]',
    'text-slate-500': 'text-[var(--ink-faint)]',
    'text-gray-50': 'text-[var(--ink)]',
    'text-gray-100': 'text-[var(--ink)]',
    'text-gray-200': 'text-[var(--ink)]',
    'text-gray-300': 'text-[var(--ink-soft)]',
    'text-gray-400': 'text-[var(--ink-soft)]',
    'text-gray-500': 'text-[var(--ink-faint)]',
}
GRADIENT_MAP = {
    'from-slate-950': 'from-[var(--hero-a)]',
    'from-slate-900': 'from-[var(--hero-b)]',
    'via-slate-900': 'via-[var(--hero-b)]',
    'to-slate-950': 'to-[var(--hero-a)]',
    'to-slate-900': 'to-[var(--hero-c)]',
}

ALL_MAPS = {}
for m in (BG_MAP, BORDER_MAP, TEXT_MAP, GRADIENT_MAP):
    ALL_MAPS.update(m)

# ترتيب من الأطول للأقصر لتفادي تداخل البادئات (slate-950 قبل slate-90...)
PATTERNS = sorted(ALL_MAPS.keys(), key=len, reverse=True)

def map_line(line: str) -> str:
    for cls in PATTERNS:
        if cls in line:
            # حدود كلمة دقيقة: لا نلمس bg-slate-900/80 (شفاف) — يُعالَج أدناه
            line = re.sub(r'(?<![\w/\-])' + re.escape(cls) + r'(?![\w/\-])', ALL_MAPS[cls], line)
    # الشفافيات الداكنة bg-slate-9X0/NN -> زجاجية
    def trans(m):
        base, alpha = m.group(1), m.group(2)
        return f'bg-[var(--glass)]/{alpha}' if False else f'bg-[color-mix(in_srgb,var(--bg-elevated)_{int(alpha)*100//100 or 80}%,transparent)]'
    line = re.sub(r'\bbg-(?:slate|gray)-(?:950|900|800)/(\d+)', lambda m: f'bg-[var(--bg-elevated)]/{m.group(1)}', line)
    line = re.sub(r'\bbg-black/(\d+)', lambda m: f'bg-[var(--bg-inset)]/{m.group(1)}', line)
    line = re.sub(r'\bbg-slate-700/(\d+)', lambda m: f'bg-[var(--bg-subtle)]/{m.group(1)}', line)
    return line

def process_file(path):
    with open(path, encoding='utf-8') as f:
        lines = f.readlines()
    out, changed = [], 0
    for ln in lines:
        stripped = ln.strip()
        if stripped.startswith(('//', '*', '/*')):
            out.append(ln); continue
        new = map_line(ln)
        if new != ln:
            changed += 1
        out.append(new)
    if changed and not DRY:
        with open(path, 'w', encoding='utf-8') as f:
            f.writelines(out)
    return changed

targets = []
for dirpath, _, files in os.walk('/workspace/src'):
    for fn in files:
        if fn.endswith('.tsx'):
            p = os.path.join(dirpath, fn)
            # استثناء وسوم media-dark بالكامل (مسرح البث + المشغّل الداكن المتعمَّد)
            with open(p, encoding='utf-8') as f:
                content = f.read()
            if 'media-dark' in content and ('LiveClassroomStudio' in fn or 'LessonPlayerShell' in fn):
                continue
            targets.append(p)

total_files = 0; total_lines = 0
for p in targets:
    c = process_file(p)
    if c:
        total_files += 1; total_lines += c
        print(f"{p}: {c} أسطر")
print(f"\n{'[DRY] ' if DRY else ''}ملفات معدّلة: {total_files} — أسطر موحَّدة: {total_lines}")
