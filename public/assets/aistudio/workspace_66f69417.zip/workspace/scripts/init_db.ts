import { Client } from 'pg';

const connectionString = 'postgresql://postgres.iucpnsrfwkfsimktbmgv:zrRHVgoNuC9eulVL@aws-1-eu-central-1.pooler.supabase.com:5432/postgres';

async function main() {
  const client = new Client({
    connectionString,
    ssl: { rejectUnauthorized: false }
  });

  try {
    console.log('Connecting to Supabase PostgreSQL...');
    await client.connect();
    console.log('Connected successfully!');

    // Create tables
    await client.query(`
      CREATE TABLE IF NOT EXISTS orbit_courses (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        slug TEXT NOT NULL,
        summary TEXT NOT NULL,
        category TEXT NOT NULL,
        level TEXT NOT NULL,
        price_minor INTEGER NOT NULL DEFAULT 0,
        currency TEXT NOT NULL DEFAULT 'USD',
        duration_hours NUMERIC NOT NULL DEFAULT 10,
        rating NUMERIC NOT NULL DEFAULT 4.9,
        reviews_count INTEGER NOT NULL DEFAULT 120,
        thumbnail_url TEXT NOT NULL,
        instructor JSONB NOT NULL,
        outcomes JSONB NOT NULL DEFAULT '[]'::jsonb,
        prerequisites JSONB NOT NULL DEFAULT '[]'::jsonb,
        sections JSONB NOT NULL DEFAULT '[]'::jsonb,
        status TEXT NOT NULL DEFAULT 'published',
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );

      CREATE TABLE IF NOT EXISTS orbit_enrollments (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        source TEXT NOT NULL DEFAULT 'free',
        enrolled_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );

      CREATE TABLE IF NOT EXISTS orbit_progress (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        lesson_id TEXT NOT NULL,
        progress_seconds INTEGER NOT NULL DEFAULT 0,
        completed BOOLEAN NOT NULL DEFAULT false,
        completed_at TIMESTAMPTZ,
        last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );

      CREATE TABLE IF NOT EXISTS orbit_certificates (
        id TEXT PRIMARY KEY,
        enrollment_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        course_title TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        instructor_name TEXT NOT NULL,
        verification_code TEXT NOT NULL UNIQUE,
        grade_percentage INTEGER NOT NULL,
        skills_verified JSONB NOT NULL DEFAULT '[]'::jsonb,
        issued_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );

      CREATE TABLE IF NOT EXISTS orbit_library_books (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        category TEXT NOT NULL,
        pages_count INTEGER NOT NULL,
        cover_url TEXT NOT NULL,
        description TEXT NOT NULL,
        download_url TEXT NOT NULL,
        published_year INTEGER NOT NULL DEFAULT 2026,
        chapters JSONB NOT NULL DEFAULT '[]'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );

      CREATE TABLE IF NOT EXISTS orbit_live_sessions (
        id TEXT PRIMARY KEY,
        course_id TEXT NOT NULL,
        course_title TEXT NOT NULL,
        instructor_id TEXT NOT NULL,
        instructor_name TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        scheduled_at TIMESTAMPTZ NOT NULL,
        duration_minutes INTEGER NOT NULL DEFAULT 60,
        status TEXT NOT NULL DEFAULT 'upcoming',
        attendees_count INTEGER NOT NULL DEFAULT 0,
        meeting_code TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS orbit_assignments (
        id TEXT PRIMARY KEY,
        course_id TEXT NOT NULL,
        course_title TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        rubric JSONB NOT NULL DEFAULT '[]'::jsonb,
        due_date TIMESTAMPTZ NOT NULL,
        max_score INTEGER NOT NULL DEFAULT 100
      );

      CREATE TABLE IF NOT EXISTS orbit_submissions (
        id TEXT PRIMARY KEY,
        assignment_id TEXT NOT NULL,
        assignment_title TEXT NOT NULL,
        student_id TEXT NOT NULL,
        student_name TEXT NOT NULL,
        submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        text_submission TEXT NOT NULL,
        repo_url TEXT,
        grade INTEGER,
        max_score INTEGER NOT NULL DEFAULT 100,
        feedback TEXT,
        status TEXT NOT NULL DEFAULT 'submitted'
      );

      CREATE TABLE IF NOT EXISTS orbit_audit_events (
        id TEXT PRIMARY KEY,
        actor_user_id TEXT,
        actor_name TEXT,
        action TEXT NOT NULL,
        resource_type TEXT NOT NULL,
        resource_id TEXT NOT NULL,
        reason TEXT,
        correlation_id TEXT,
        safe_metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
    `);

    console.log('Tables created or verified in Supabase PostgreSQL!');

    await client.end();
  } catch (err) {
    console.error('Database setup error:', err);
    process.exit(1);
  }
}

main();
