#!/usr/bin/env python3
"""الجولة الثالثة: توحيد ألوان الهوية (amber/cyan/emerald الفاتحة) عبر متغيرات CSS في index.css."""
import re, os

# 1) إضافة قواعد الوضع النهاري لألوان اللوحات في index.css
css_path = '/workspace/src/index.css'
c = open(css_path, encoding='utf-8').read()

addition = '''
/* ============================================================
   توحيد هوية لوحات التحكم (المعلمة/الإدارة/الطالب) في الوضع النهاري:
   درجات amber/cyan/emerald الفاتحة المصممة للوضع الداكن تُحاكى
   إلى نظيراتها العميقة المقروءة فوق الأسطح الفاتحة — بلا تعديل JSX.
   ============================================================ */
html:not(.dark) .text-amber-200, html:not(.dark) .text-amber-300 { color: #b45309 !important; }
html:not(.dark) .text-amber-400 { color: #d97706 !important; }
html:not(.dark) .text-cyan-200, html:not(.dark) .text-cyan-300, html:not(.dark) .text-cyan-400 { color: #0e7490 !important; }
html:not(.dark) .text-teal-200, html:not(.dark) .text-teal-300 { color: #0f766e !important; }
html:not(.dark) .text-emerald-200, html:not(.dark) .text-emerald-300, html:not(.dark) .text-emerald-400 { color: #047857 !important; }
html:not(.dark) .text-sky-200, html:not(.dark) .text-sky-300, html:not(.dark) .text-sky-400 { color: #0369a1 !important; }
html:not(.dark) .text-violet-300, html:not(.dark) .text-violet-400 { color: #6d28d9 !important; }
html:not(.dark) .text-purple-300, html:not(.dark) .text-purple-400 { color: #7e22ce !important; }
html:not(.dark) .text-indigo-300, html:not(.dark) .text-indigo-400 { color: #4338ca !important; }
html:not(.dark) .text-rose-200, html:not(.dark) .text-rose-300, html:not(.dark) .text-rose-400 { color: #be123c !important; }
html:not(.dark) .text-pink-300, html:not(.dark) .text-pink-400 { color: #be185d !important; }
html:not(.dark) .text-orange-300, html:not(.dark) .text-orange-400 { color: #c2410c !important; }
html:not(.dark) .text-yellow-200, html:not(.dark) .text-yellow-300 { color: #a16207 !important; }
html:not(.dark) .text-green-200, html:not(.dark) .text-green-300 { color: #15803d !important; }
html:not(.dark) .text-blue-200, html:not(.dark) .text-blue-300 { color: #1d4ed8 !important; }
/* خلفيات التدرج الذهبية للأزرار النشطة: النص يبقى داكناً فوقها عمداً (تباين مقصود) */
html:not(.dark) [class*="from-amber-400"], html:not(.dark) [class*="to-orange-500"] { color: #ffffff !important; }
'''

marker = '/* احترام تقليل الحركة */'
if 'توحيد هوية لوحات التحكم' not in c and marker in c:
    c = c.replace(marker, addition.strip() + '\n\n' + marker)
    open(css_path, 'w', encoding='utf-8').write(c)
    print('index.css: تمت إضافة طبقة محاكاة ألوان اللوحات للنهار')
else:
    print('index.css: موجود مسبقاً أو الوسم غير找到一个 — فحص يدوي')

# 2) إصلاح أخطاء دقيقة نشأت من الجولة السابقة:
fixes = [
    # شارة التاب النشط: نص ذهبي فوق سطح فاتح -> ذهبي عميق
    ('bg-[var(--bg-inset)] text-amber-300', 'bg-[var(--bg-inset)] text-amber-700'),
]
count = 0
for dirpath, _, files in os.walk('/workspace/src'):
    for fn in files:
        if not fn.endswith('.tsx'): continue
        p = os.path.join(dirpath, fn)
        content = open(p, encoding='utf-8').read()
        orig = content
        for a, b in fixes:
            content = content.replace(a, b)
        if content != orig:
            n = sum(orig.count(a) for a, _ in fixes)
            count += n
            open(p, 'w', encoding='utf-8').write(content)
print(f'إصلاحات دقيقة: {count}')
