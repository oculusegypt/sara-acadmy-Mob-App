#!/usr/bin/env python3
"""الجولة الثانية: hover:bg-white/N، bg-white/N (أسطح تفاعلية)، والأصناف الداكنة المتبقية."""
import re, os, sys

DRY = '--apply' not in sys.argv

SUBS = [
    # أسطح تفاعلية شفافة (تُستخدم فوق الأسطح الفاتحة والداكنة) -> طبقة حبر خفيفة تعمل في الوضعين
    (r'\bhover:bg-white/(\d+)', r'hover:bg-[color-mix(in_srgb,var(--ink)_\1%,transparent)]'),
    (r'\bbg-white/(5|10|15|20|25)\b', r'bg-[color-mix(in_srgb,var(--ink)_\1%,transparent)]'),
    (r'\bbg-white/(40|70|85|95)\b', r'bg-[color-mix(in_srgb,var(--ink)_\1%,transparent)]'),
    # نصوص داكنة متبقية على أسطح فاتحة
    (r'\btext-slate-600\b', 'text-[var(--ink-soft)]'),
    (r'\btext-slate-700\b', 'text-[var(--ink)]'),
    (r'\btext-slate-800\b', 'text-[var(--ink)]'),
    (r'\btext-slate-900\b', 'text-[var(--ink)]'),
    (r'\btext-slate-950\b', 'text-[var(--ink)]'),
    (r'\btext-gray-600\b', 'text-[var(--ink-soft)]'),
    (r'\btext-gray-700\b', 'text-[var(--ink)]'),
    (r'\btext-gray-800\b', 'text-[var(--ink)]'),
    (r'\btext-gray-900\b', 'text-[var(--ink)]'),
    (r'\bbg-slate-100\b', 'bg-[var(--bg-subtle)]'),
    (r'\bbg-slate-200\b', 'bg-[var(--bg-inset)]'),
    (r'\bbg-gray-100\b', 'bg-[var(--bg-subtle)]'),
    (r'\bbg-gray-200\b', 'bg-[var(--bg-inset)]'),
    (r'\bbg-white\b(?!/) ', 'bg-[var(--bg-elevated)] '),  # أمان
]

def map_line(line):
    for pat, rep in SUBS:
        line = re.sub(pat, rep, line)
    return line

total_files = total_lines = 0
for dirpath, _, files in os.walk('/workspace/src'):
    for fn in files:
        if not fn.endswith('.tsx'): continue
        p = os.path.join(dirpath, fn)
        content = open(p, encoding='utf-8').read()
        if 'media-dark' in content and ('LiveClassroomStudio' in fn or 'LessonPlayerShell' in fn):
            continue
        lines = content.splitlines(keepends=True)
        out = []; changed = 0
        for ln in lines:
            s = ln.strip()
            if s.startswith(('//', '*', '/*')):
                out.append(ln); continue
            new = map_line(ln)
            if new != ln: changed += 1
            out.append(new)
        if changed:
            total_files += 1; total_lines += changed
            print(f"{p}: {changed}")
            if not DRY:
                open(p, 'w', encoding='utf-8').writelines(out)
print(f"\n{'[DRY] ' if DRY else ''}ملفات: {total_files} — أسطر: {total_lines}")
