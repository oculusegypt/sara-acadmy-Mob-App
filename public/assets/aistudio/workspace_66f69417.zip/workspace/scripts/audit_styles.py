#!/usr/bin/env python3
"""فحص شامل لتضاربات الاستايل: أصناف داكنة صلبة خارج وسوم media-dark."""
import re, os, sys

ROOT = '/workspace/src'
DARK_SOLID = re.compile(r'\b(?:bg|border|text|from|to|via)-(?:slate|gray|grey|zinc|neutral)-(?:50|100|200|300|400|500|600|700|800|900|950)\b')
TEXT_WHITE = re.compile(r'\btext-white\b')
MEDIA_TOKEN = re.compile(r'media-dark')

def is_media_line(line: str) -> bool:
    return bool(MEDIA_TOKEN.search(line))

report = {}
total = 0
for dirpath, _, files in os.walk(ROOT):
    for fn in files:
        if not fn.endswith(('.tsx', '.ts')):
            continue
        p = os.path.join(dirpath, fn)
        with open(p, encoding='utf-8') as f:
            lines = f.readlines()
        hits = []
        for i, line in enumerate(lines, 1):
            if is_media_line(line):
                continue
            cls = DARK_SOLID.findall(line) + TEXT_WHITE.findall(line)
            # استثناء تعليقات
            if line.strip().startswith(('//', '*', '/*')):
                continue
            if cls:
                hits.append((i, sorted(set(cls))))
        if hits:
            report[p] = hits
            total += len(hits)

for p, hits in sorted(report.items(), key=lambda kv: -len(kv[1])):
    print(f"\n=== {p} ({len(hits)} أسطر) ===")
    for ln, cls in hits[:200]:
        print(f"  L{ln}: {', '.join(cls)}")

print(f"\nTOTAL non-media dark-class lines: {total}")
