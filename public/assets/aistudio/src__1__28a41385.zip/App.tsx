import { useState } from "react"

const A = "/assets/"

type Screen = "parent-home" | "children" | "empty" | "profile" | "age7-profile" | "add" | "young-overview" | "young-home" | "older-profile" | "older-home"

type Age = "حتى 6 سنوات" | "7 إلى 8 سنوات" | "9 إلى 14 سنة"

const asset = (name: string) => `${A}${name}`

function Icon({ src, className = "" }: { src: string className?: string }) {
  return (
    <img
      alt=""
      aria-hidden="true"
      className={`object-contain ${className}`}
      src={asset(src)}
    />
  )
}

function Header({ compact = false }: { compact?: boolean }) {
  return (
    <header className={`app-header ${compact ? "compact" : ""}`}>
      <button className="header-action" aria-label="الإشعارات">
        <Icon src="7cc5a.svg" />
        <span>3</span>
      </button>
      <button
        className="brand-lockup"
        onClick={() => location.reload()}
        aria-label="سارة العربي"
      >
        <Icon src="eda5a.png" />
        {!compact && (
          <>
            <strong>سارة العربي</strong>
            <small>منصة تعليمية متكاملة</small>
          </>
        )}
      </button>
      <button className="parent-profile" aria-label="حساب ولي الأمر">
        <Icon src="562d0.png" />
        <b>‹</b>
      </button>
    </header>
  )
}

const parentNav = [
  ["الرئيسية", "033c1.svg", "parent-home"],
  ["أبنائي", "bf877.svg", "children"],
  ["الجدول", "0c4da.svg", "parent-home"],
  ["الإشعارات", "11645.svg", "parent-home"],
  ["المزيد", "3b075.svg", "parent-home"],
] as const

function ParentNav({
  active,
  go,
}: {
  active: "الرئيسية" | "أبنائي"
  go: (s: Screen) => void
}) {
  return (
    <nav className="bottom-nav" aria-label="التنقل الرئيسي">
      {parentNav.map(([label, icon, screen]) => (
        <button
          className={active === label ? "active" : ""}
          key={label}
          onClick={() => go(screen)}
        >
          <Icon src={icon} />
          <span>{label}</span>
        </button>
      ))}
    </nav>
  )
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="section-title">
      <h2>{children}</h2>
      <span />
    </div>
  )
}

const services = [
  ["الفصل المباشر", "انضم لفصلك الآن", "b3ca0.svg", "mint"],
  ["حجز الحصص", "اختر موعدك بسهولة", "d9644.svg", "blue"],
  ["البرامج التعليمية", "اكتشف برامجنا المميزة", "1fee8.svg", "lavender"],
  ["الدعم والمساعدة", "نحن معك دائمًا", "57116.svg", "pink"],
  ["التقارير والمتابعة", "تابع تقدم أبنائك", "008e9.svg", "aqua"],
  ["الاشتراكات والفواتير", "إدارة اشتراكاتك", "831df.svg", "peach"],
]

function ParentHome({ go }: { go: (s: Screen) => void }) {
  return (
    <Page>
      <Header />
      <main className="parent-home">
        <section className="parent-hero">
          <Icon src="2b41b.png" />
          <div>
            <h1>
              معًا .. نحو مستقبل
              <br />
              تعليمي أفضل
            </h1>
            <p>تعليم تفاعلي .. متابعة مستمرة .. نجاح مضمون</p>
            <button className="gold small" onClick={() => go("young-overview")}>
              ابدأ التعلم الآن ←
            </button>
          </div>
        </section>
        <section className="stats">
          {[
            ["ecd7c.svg", "18", "نقاط التميز"],
            ["af526.svg", "95%", "معدل الإنجاز"],
            ["d9644.svg", "12", "حصة هذا الشهر"],
            ["83047.svg", "5", "أبناؤك"],
          ].map(([icon, value, label]) => (
            <div key={label}>
              <Icon src={icon} />
              <b>{value}</b>
              <span>{label}</span>
            </div>
          ))}
        </section>
        <SectionTitle>خدماتنا الرئيسية</SectionTitle>
        <section className="service-grid">
          {services.map(([title, sub, icon, color]) => (
            <button
              className={`service ${color}`}
              key={title}
              onClick={() =>
                title === "البرامج التعليمية" && go("young-overview")
              }
            >
              <Icon src={icon} />
              <strong>{title}</strong>
              <small>{sub} ‹</small>
            </button>
          ))}
        </section>
        <SectionTitle>أحدث الإعلانات</SectionTitle>
        <button className="announcement">
          <div>
            <strong>بداية الفصل الدراسي الجديد</strong>
            <span>نتمنى لجميع طلابنا عامًا دراسيًا موفقًا ومليئًا بالنجاح</span>
          </div>
          <span>عرض الكل ←</span>
        </button>
        <SectionTitle>أبنائي الأعزاء</SectionTitle>
        <section className="children-strip">
          {[
            ["محمد أحمد", "المستوى الثاني", "a2736.png"],
            ["فاطمة أحمد", "المستوى الأول", "1ffe4.png"],
            ["علي أحمد", "المستوى الثالث", "a2736.png"],
          ].map(([name, level, img]) => (
            <button key={name} onClick={() => go("profile")}>
              <Icon src={img} />
              <strong>{name}</strong>
              <small>{level}</small>
              <b>عرض التفاصيل</b>
            </button>
          ))}
          <button className="add-child" onClick={() => go("add")}>
            <span>＋</span>
            <strong>إضافة ابن جديد</strong>
          </button>
        </section>
        <section className="purple-banner">
          <Icon src="16e86.svg" />
          <div>
            <strong>مع سارة العربي ..</strong>
            <span>كل خطوة نحو التميز</span>
          </div>
          <button className="gold small" onClick={() => go("young-overview")}>
            اكتشف المزيد ←
          </button>
        </section>
      </main>
      <DemoBadge />
      <ParentNav active="الرئيسية" go={go} />
    </Page>
  )
}

function DemoBadge({ onClick }: { onClick?: () => void }) {
  return (
    <button className="demo-badge" onClick={onClick}>
      مثال تجريبي
    </button>
  )
}

const childRows: [string, Age, string, Screen][] = [
  ["اسم الطالب", "حتى 6 سنوات", "1ffe4.png", "profile"],
  ["اسم الطالب", "7 إلى 8 سنوات", "a2736.png", "age7-profile"],
  ["اسم الطالب", "9 إلى 14 سنة", "a2736.png", "older-profile"],
]

function Children({ go }: { go: (s: Screen) => void }) {
  return (
    <Page>
      <Header />
      <main className="content">
        <h1>أبنائي الأعزاء</h1>
        <p className="lead">
          كل رحلة تعلم تبدأ بخطوة. تابع تجربة كل طفل في مكان واحد.
        </p>
        <DemoBadge onClick={() => go("empty")} />
        <div className="child-list">
          {childRows.map(([name, age, img, screen]) => (
            <button className="child-row" key={age} onClick={() => go(screen)}>
              <Icon src={img} />
              <div>
                <h2>{name}</h2>
                <p>{age}</p>
                <p>البرنامج والمستوى: —</p>
                <b>عرض ملف الطفل ←</b>
              </div>
            </button>
          ))}
        </div>
        <button className="primary wide" onClick={() => go("add")}>
          إضافة طفل +
        </button>
        <p className="hint">لن تظهر للطفل معلومات الاشتراكات أو المدفوعات.</p>
      </main>
      <ParentNav active="أبنائي" go={go} />
    </Page>
  )
}

function EmptyChildren({ go }: { go: (s: Screen) => void }) {
  return (
    <Page>
      <Header />
      <main className="empty-state">
        <Icon src="83047.svg" />
        <h1>لنبدأ رحلة التعلم</h1>
        <p>أضف بيانات طفلك لتظهر البرامج المناسبة لعمره وجدوله وتقدمه هنا.</p>
        <button className="primary wide" onClick={() => go("add")}>
          إضافة طفل
        </button>
        <span>نموذج حالة فارغة</span>
      </main>
      <ParentNav active="أبنائي" go={go} />
    </Page>
  )
}

function Profile({
  go,
  age = "حتى 6 سنوات",
}: {
  go: (s: Screen) => void
  age?: Age
}) {
  const target =
    age === "9 إلى 14 سنة"
      ? "older-home"
      : age === "7 إلى 8 سنوات"
        ? "young-home"
        : "young-home"
  return (
    <Page>
      <Header />
      <main className="content profile-content">
        <button className="back" onClick={() => go("children")}>
          ‹
        </button>
        <h1>ملف الطفل</h1>
        <section className="profile-card identity">
          <Icon src="1ffe4.png" />
          <div>
            <h2>اسم الطالب</h2>
            <p>{age} • الدولة: —</p>
            <span>مثال تجريبي</span>
          </div>
        </section>
        <section className="profile-card compact-card">
          <h3>حالة الاشتراك</h3>
          <span className="status">غير نشط</span>
        </section>
        <section className="profile-card">
          <h3>حصته القادمة</h3>
          <p>لا توجد حصة قادمة</p>
          <button className="primary" onClick={() => go("young-overview")}>
            استعرض البرامج المناسبة ←
          </button>
        </section>
        <section className="profile-card">
          <h3>البرنامج والمستوى</h3>
          <p>البرنامج: — &nbsp; • &nbsp; المستوى: —</p>
          <small>التقدم</small>
          <div className="progress">
            <i />
          </div>
          <p className="hint">سيظهر التقدم بعد بدء التعلم.</p>
        </section>
        <button className="gold wide" onClick={() => go(target)}>
          فتح تجربة الطفل ←
        </button>
        <p className="hint">تجربة آمنة ومناسبة للعمر، دون بيانات مالية.</p>
      </main>
      <ParentNav active="أبنائي" go={go} />
    </Page>
  )
}

function AddChild({
  go,
  save,
}: {
  go: (s: Screen) => void
  save: (name: string, age: Age) => void
}) {
  const [name, setName] = useState("")
  const [age, setAge] = useState<Age>("حتى 6 سنوات")
  const [country, setCountry] = useState("")
  return (
    <Page>
      <Header />
      <main className="content add-form">
        <h1>إضافة طفل</h1>
        <p className="lead">
          البيانات الأساسية فقط، لتحديد تجربة التعلم المناسبة.
        </p>
        <span className="form-badge">نموذج تصميم</span>
        <label className="field">
          <b>اسم الطفل</b>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="اسم الطالب"
          />
        </label>
        <fieldset className="age-field">
          <legend>الفئة العمرية</legend>
          <div>
            {(["حتى 6 سنوات", "7 إلى 8 سنوات", "9 إلى 14 سنة"] as Age[]).map(
              (item) => (
                <button
                  type="button"
                  className={age === item ? "selected" : ""}
                  onClick={() => setAge(item)}
                  key={item}
                >
                  {item}
                </button>
              ),
            )}
          </div>
        </fieldset>
        <label className="field">
          <b>الدولة</b>
          <select value={country} onChange={(e) => setCountry(e.target.value)}>
            <option value="">اختر الدولة</option>
            <option>المملكة العربية السعودية</option>
            <option>الإمارات العربية المتحدة</option>
            <option>مصر</option>
          </select>
        </label>
        <p className="hint">
          لا نطلب بيانات مالية أو معلومات إضافية عن الطفل هنا.
        </p>
        <button
          className="primary wide"
          onClick={() => {
            save(name || "اسم الطالب", age)
            go(
              age === "9 إلى 14 سنة"
                ? "older-profile"
                : age === "7 إلى 8 سنوات"
                  ? "age7-profile"
                  : "profile",
            )
          }}
        >
          معاينة ملف الطفل ←
        </button>
        <button className="secondary wide" onClick={() => go("children")}>
          العودة إلى أبنائي
        </button>
      </main>
      <ParentNav active="أبنائي" go={go} />
    </Page>
  )
}

const subjects = [
  ["اللغة العربية", "تعلم الحروف والكلمات", "7e88c.svg", "peach"],
  ["الرياضيات", "أرقام وعمليات بسيطة", "389fc.svg", "lavender"],
  ["العلوم", "اكتشف عالمك من حولك", "819af.svg", "lavender"],
  ["الفنون", "أبدع وطوّر مهاراتك", "e03dc.svg", "peach"],
  ["الأنشطة الرياضية", "لعب ونشاط وصحة", "38f28.svg", "blue"],
  ["الأنشطة الاجتماعية", "تعلم مع أصدقائك", "a1d23.svg", "mint"],
]

function YoungOverview({ go }: { go: (s: Screen) => void }) {
  return (
    <Page child>
      <Header />
      <main className="young-overview">
        <section className="young-hero">
          <Icon src="e1eb1.png" />
          <div>
            <b>مستوى الروضة</b>
            <h1>تعلم .. العب .. اكتشف</h1>
            <p>
              رحلة تعليمية ممتعة لطفلك
              <br />
              في عالم مليء بالمعرفة
            </p>
            <button className="gold small" onClick={() => go("young-home")}>
              استكشف الآن ←
            </button>
          </div>
        </section>
        <section className="stats">
          {[
            ["83047.svg", "5", "أطفال مسجلين"],
            ["d9644.svg", "12", "حصة هذا الشهر"],
            ["af526.svg", "95%", "معدل الإنجاز"],
            ["ecd7c.svg", "18", "نقطة التميز"],
          ].map(([icon, value, label]) => (
            <div key={label}>
              <Icon src={icon} />
              <b>{value}</b>
              <span>{label}</span>
            </div>
          ))}
        </section>
        <SectionTitle>مميزات المستوى</SectionTitle>
        <section className="service-grid subjects">
          {subjects.map(([title, sub, icon, color]) => (
            <button
              className={`service ${color}`}
              key={title}
              onClick={() => go("young-home")}
            >
              <Icon src={icon} />
              <strong>{title}</strong>
              <small>{sub} ‹</small>
            </button>
          ))}
        </section>
        <SectionTitle>تقدم طفلك</SectionTitle>
        <section className="progress-card">
          <Icon src="16e86.svg" />
          <div>
            <b>مستوى الروضة - الفصل الأول</b>
            <div className="progress">
              <i style={{ width: "75%" }} />
            </div>
            <strong>75% من الدروس مكتملة</strong>
          </div>
        </section>
        <SectionTitle>الحصص القادمة</SectionTitle>
        <section className="class-card">
          <div>
            <small>السبت</small>
            <b>27</b>
            <span>سبتمبر</span>
          </div>
          <div>
            <b>لغة عربية</b>
            <span>10:00 ص - 10:45 ص</span>
          </div>
          <button className="primary">الانضمام للحصة</button>
        </section>
        <section className="purple-banner">
          <Icon src="99bcf.svg" />
          <div>
            <strong>مكافآت وإنجازات</strong>
            <span>كل إنجاز .. يقربك من النجاح</span>
          </div>
          <button className="gold small">عرض المكافآت ←</button>
        </section>
      </main>
      <ChildNav active="الرئيسية" go={go} />
    </Page>
  )
}

function ChildNav({
  active,
  go,
  older = false,
}: {
  active: string
  go: (s: Screen) => void
  older?: boolean
}) {
  const nav = older
    ? [
        ["الرئيسية", "033c1.svg"],
        ["جدولي", "0c4da.svg"],
        ["المصادر", "b0a2f.svg"],
        ["تقدمي", "516aa.svg"],
      ]
    : [
        ["الرئيسية", "033c1.svg"],
        ["محتواي", "b0a2f.svg"],
        ["جدولي", "0c4da.svg"],
        ["إنجازاتي", "516aa.svg"],
        ["المزيد", "3b075.svg"],
      ]
  return (
    <nav className="bottom-nav child-nav">
      {nav.map(([label, icon]) => (
        <button
          className={active === label ? "active" : ""}
          key={label}
          onClick={() => go(older ? "older-home" : "young-home")}
        >
          <Icon src={icon} />
          <span>{label}</span>
        </button>
      ))}
    </nav>
  )
}

function YoungHome({ go }: { go: (s: Screen) => void }) {
  return (
    <Page child>
      <header className="student-header">
        <div>
          <strong>سارة العربي</strong>
          <Icon src="eda5a.png" />
        </div>
        <div>
          <button>♧</button>
          <Icon src="1ffe4.png" />
        </div>
      </header>
      <main className="student-home">
        <h1>الرئيسية</h1>
        <section className="learning-hero">
          <div className="book-face">
            <span>•⌣•</span>
            <b>☆</b>
          </div>
          <div>
            <h2>أهلاً يا بطل!</h2>
            <p>ماذا سنتعلم اليوم؟</p>
          </div>
        </section>
        <section className="next-class">
          <Icon src="e1eb1.png" />
          <div>
            <h2>حصتي القادمة</h2>
            <p>لا توجد حصة الآن</p>
            <button className="primary">ادخل الحصة</button>
            <small>سيظهر زر الدخول عند موعد حصتك.</small>
          </div>
        </section>
        <section className="big-subjects">
          <button>
            <Icon src="97c9d.svg" />
            <b>اللغة العربية</b>
          </button>
          <button>
            <Icon src="2beed.svg" />
            <b>الرياضيات</b>
          </button>
        </section>
        <h2 className="plain-title">أنشطتي</h2>
        <section className="activities">
          <button>
            <span>‹</span>
            <b>وصّل الصورة</b>
            <Icon src="8127b.png" />
          </button>
          <button>
            <span>‹</span>
            <b>تتبّع الحرف</b>
            <strong>أ</strong>
          </button>
        </section>
        <h2 className="plain-title">إنجازاتي</h2>
        <section className="star-strip">
          {[1, 2, 3, 4].map((n) => (
            <button key={n}>
              <Icon src="ecd7c.svg" />
              <span>—</span>
            </button>
          ))}
        </section>
      </main>
      <ChildNav active="الرئيسية" go={go} />
    </Page>
  )
}

function OlderHome({ go }: { go: (s: Screen) => void }) {
  return (
    <Page child>
      <header className="older-header">
        <button aria-label="الإشعارات">♧</button>
        <span>من 9 إلى 14 سنة</span>
        <div>
          <Icon src="eda5a.png" />
          <b>سارة العربي</b>
        </div>
      </header>
      <main className="content older-content">
        <h1>أهلًا بك، اسم الطالب</h1>
        <p className="lead">خطّط ليومك، وتابع رحلة تعلمك.</p>
        <span className="form-badge">نموذج تصميم</span>
        <section className="today-card">
          <h2>المهم اليوم</h2>
          <p>لا توجد حصة قادمة</p>
          <button className="gold wide">عرض جدولي الأسبوعي ←</button>
        </section>
        <section className="profile-card">
          <h2>برنامجي ومستواي</h2>
          <p>البرنامج: — &nbsp; • &nbsp; المستوى: —</p>
        </section>
        <SectionTitle>مهامي التعليمية</SectionTitle>
        <section className="profile-card tasks">
          <p>
            لا توجد واجبات معلقة <span>▤</span>
          </p>
          <p>
            لا توجد اختبارات متاحة <span>✓</span>
          </p>
        </section>
        <button className="resources">
          <Icon src="58e24.svg" />
          <b>كتبي ومصادري</b>
        </button>
        <p className="hint">سيظهر تقدمك وسجل حضورك بعد بدء التعلم.</p>
      </main>
      <ChildNav older active="الرئيسية" go={go} />
    </Page>
  )
}

function Page({
  children,
  child = false,
}: {
  children: React.ReactNode
  child?: boolean
}) {
  return (
    <div className={`page ${child ? "child-page" : ""}`} dir="rtl">
      {children}
    </div>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("parent-home")
  const [, setDraft] = useState<{ name: string age: Age } | null>(null)
  const go = (next: Screen) => {
    setScreen(next)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  if (screen === "children") return <Children go={go} />
  if (screen === "empty") return <EmptyChildren go={go} />
  if (screen === "profile") return <Profile go={go} />
  if (screen === "age7-profile") return <Profile go={go} age="7 إلى 8 سنوات" />
  if (screen === "older-profile") return <Profile go={go} age="9 إلى 14 سنة" />
  if (screen === "add")
    return <AddChild go={go} save={(name, age) => setDraft({ name, age })} />
  if (screen === "young-home") return <YoungHome go={go} />
  if (screen === "older-home") return <OlderHome go={go} />
  if (screen === "young-overview") return <YoungOverview go={go} />
  return <ParentHome go={go} />
}
